﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackgammonLogic
{
    public class Board
    {
        private List<Triangle> triangles;

        public Board()
        {
            triangles = new List<Triangle>(24);
            InitBoard();
        }

        public Triangle this[int index]
        {
            get
            {
                return triangles[index];
            }
        }

        public void InitBoard()
        {
            for (int i = 0; i < triangles.Count; i++)
            {
                switch (i)
                {
                    case 0:
                        triangles[i] = new Triangle(2, CheckerColor.White);
                        break;
                    case 5:
                        triangles[i] = new Triangle(5, CheckerColor.Black);
                        break;
                    case 7:
                        triangles[i] = new Triangle(3, CheckerColor.Black);
                        break;
                    case 11:
                        triangles[i] = new Triangle(5, CheckerColor.White);
                        break;
                    case 12:
                        triangles[i] = new Triangle(5, CheckerColor.Black);
                        break;
                    case 16:
                        triangles[i] = new Triangle(3, CheckerColor.White);
                        break;
                    case 18:
                        triangles[i] = new Triangle(5, CheckerColor.White);
                        break;
                    case 23:
                        triangles[i] = new Triangle(2, CheckerColor.Black);
                        break;
                    default:
                        triangles[i] = new Triangle();
                        break;
                }
            }
        }
    }
}
