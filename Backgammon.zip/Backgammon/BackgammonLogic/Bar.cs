﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackgammonLogic
{
    public class Bar
    {
        public static CheckerColor Color { get; set; }
        public static int Checkers { get; set; }
        public Bar()
        {
            Color = CheckerColor.Empty;
            Checkers = 0;
        }
    }
}
