﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackgammonLogic
{
    class BlackPlayer : IPlayer
    {
        private CheckerColor color;
        public BlackPlayer(CheckerColor initColor)
        {
            color = initColor;
        }
        bool IsPlayerTurn { get; set; }
        CheckerColor Color
        {
            get
            {
                return color;
            }
        }
        bool MakeMove(int currentIndex, int Move);
        bool MakeFinalMove(int currentIndex, int Move);
        bool MakeBarMove(int Move);
        List<Triangle> GetLegalBarMoves();
        List<Triangle> GetLegalMoves();
        List<Triangle> GetLegalFinalMoves();
    }
}
