﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackgammonLogic
{
    public class Triangle
    {
        private int numberOfCheckers;
        private CheckerColor color;

        public Triangle()
        {
            numberOfCheckers = 0;
            color = CheckerColor.Empty;
        }
        public Triangle(int initCheckers,CheckerColor initcolor)
        {
            numberOfCheckers = initCheckers;
            color = initcolor;
        }

        public int NumberOfCheckers
        {
            get
            {
                return numberOfCheckers;
            }
        }

        public CheckerColor Color
        {
            get
            {
                return color;
            }
        }
        public bool RemoveChecker()
        {
            if (numberOfCheckers > 0)
            {
                numberOfCheckers--;
                if (numberOfCheckers == 0)
                {
                    color = CheckerColor.Empty;
                }
                return true;
            }
            else
            {
                return false;
            }
        }
        private void AddChecker()
        {
            numberOfCheckers++;
        }
        private void AddFirstChecker(CheckerColor newColor)
        {
            color = newColor;
            numberOfCheckers = 1;
        }

        private void EatChecker()
        {
            if (color == CheckerColor.Black)
            {
                color = CheckerColor.White;
                Bar.Color = CheckerColor.Black;
                Bar.Checkers++;
            }
            else
            {
                color = CheckerColor.Black;
                Bar.Color = CheckerColor.White;
                Bar.Checkers++;
            }
        }

        public bool MoveChecker(CheckerColor newColor)
        {
            if (color == CheckerColor.Empty)
            {
                AddFirstChecker(newColor);
                return true;
            }
            else if (color == newColor)
            {
                AddChecker();
                return true;
            }
            else
            {
                if (numberOfCheckers == 1)
                {
                    EatChecker();
                    return true;
                }
            }
            return false;
        }
    }
}
