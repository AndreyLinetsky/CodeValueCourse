﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackgammonLogic
{
    class GameController
    {
        private IPlayer firstPlayer;
        private IPlayer secondPlayer;
        private Board gameBoard;
        private Dice gameDice;
        private Bar GameBar;
        public GameController(int indFirstPlayer, int indSecondPlayer)
        {
            if (indFirstPlayer == 1)
            {
                firstPlayer = new BlackPlayer();
            }
            else
            {
                firstPlayer = new BlackAI();
            }
            if (indSecondPlayer == 1)
            {
                secondPlayer = new WhitePlayer();
            }
            else
            {
                secondPlayer = new WhiteAI();
            }
            gameBoard = new Board();
            gameDice = new Dice();
            DecideFirstTurn();
        }
        public void DecideFirstTurn()
        {
            while (gameDice.FirstDice == gameDice.SecondDice)
            {
                gameDice.ThrowDice();
                if (gameDice.FirstDice > gameDice.SecondDice)
                {
                    firstPlayer.IsPlayerTurn = true;
                }
                else if (gameDice.FirstDice < gameDice.SecondDice)
                {
                   secondPlayer.IsPlayerTurn = true;
                }
            }
        }

        public bool PlayTurn(int SourceIndex,int Move)
        {

            if (checkerSource == 2 &&
                Bar.Color
        }
    }
}
